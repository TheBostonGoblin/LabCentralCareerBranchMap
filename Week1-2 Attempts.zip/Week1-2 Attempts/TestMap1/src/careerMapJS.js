window.onload = init;

let ctx;
let canvas;

function init(){
    canvas = document.querySelector("#myCanvas");
    ctx = canvas.getContext("2d");
    draw();
}
function draw(){
    ctx.save();
    ctx.fillStyle = "blue";
    ctx.strokeStyle = "black";
    ctx.lineWidth = 10;
    ctx.rect(125,225,300,300);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
}