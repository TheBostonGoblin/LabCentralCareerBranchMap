import "https://d3js.org/d3.v7.min.js";
import "https://dagrejs.github.io/project/dagre-d3/latest/dagre-d3.js";
// Create a new directed graph
var g = new dagreD3.graphlib.Graph().setGraph({});

// var nodes = [
//     "10007154_1100",
//     "148570017_1100",
//     "148570018_1100",
//     "148570019_1100",
//     "148570025_1100",
//     "148570010_1100",
//     "148570021_1100",
//     "148570020_1100",
//     "148570026_1100",
//     "148570011_1100",
//     "148570022_1100",
//     "148570010_1200",
//     "148570020_1200",
//     "148570026_1200",
//     "148570023_1100",
//     "148570011_1200",
//     "148570023_1200"
// ];
// var links = [
//     ["148570017_1100"],//54_1100
//     ["148570018_1100"],//17_1100
//     ["148570019_1100", "148570025_1100"],//18_1100
//     ["148570020_1100", "148570010_1100", "148570021_1100"],//19_1100
//     ["148570010_1100", "148570026_1100"],//25_1100
//     ["148570011_1100", "148570010_1200"],//10_1100
//     ["148570022_1100"],//21_1100
//     ["148570020_1200"],//20_1100
//     ["148570026_1200"],//26_1100
//     [],//11_1100
//     ["148570023_1100"],//22_1100
//     ["148570011_1200"],//10_1200
//     [],//20_1200
//     ["148570011_1200"],//26_1200
//     ["148570023_1200"],//23_1100
//     [],//11_1200
//     []//23_1200

// ];
// var nodes = [
//     "Lab Assistance\nSalary: 35,000",
//     "Bio Researcher Intern\nSalary: 50,000",
//     "Bio Associate Researcher\nSalary: 75,000",
//     "Bio Internmidate Researcher\nSalary: 80,000",
//     "Bio Senior Researcher\nSalary: 90,000",
//     "Chem Researcher Intern\nSalary: 45,000",
//     "Chem Associate Researcher\nSalary: 55,000",
//     "Chem Internmidate Researcher\nSalary: 85,000",
//     "Chem Senior Researcher\nSalary: 105,000",
//     "Lab Managment Intern\nSalary: 46,700",
//     "Junior Lab Manager\nSalary: 66,700",
//     "Senior Lab Manager\nSalary: 66,700"
// ];
// var links = [
//     ["Bio Researcher Intern\nSalary: 50,000","Chem Researcher Intern\nSalary: 45,000","Lab Managment Intern\nSalary: 46,700" ],
//     ["n/a"],
//     ["n/a"]
// ]

var nodes = [
    "Intern",
    "Pos.1A",
    "Pos.1B",
    "Pos.1C"

]
var links = 
    ["Pos.1A","Pos.1B","Pos.1C"],
    ["n/a"],
    ["n/a"],
    ["n/a"],
]

// Automatically label each of the nodes
nodes.forEach(function (node) {
    g.setNode(node, { label: node });
});
let nodeElement = d3.selectAll("g")//.on("click",function(){console.log(`clicked`)});
console.log(nodeElement.length);
let tempstring;
// console.log(links[0][0]);
// for (let i = 0; i < nodes.length; i++) {
//     for (let u = 0; u < links[i].length; u++) {
//         if (links[i][0] == "n/a") {
//             console.log(`node:${nodes[i]} has NO children`);
//         }
//         else {
//             console.log(`node:${nodes[i]} HAS children!`);
//             g.setEdge(nodes[i].toString(),links[i][u].toString(), { label: "" });

//         }

//     }
// }

nodes.forEach(function(node){

    //g.node.on("click",function(){console.log(`${node} has been clicked`)});
})


 //g.setEdge(0,1,{ label: "" });
 //g.setEdge(0,2,{ label: "" });
// console.log(links[0].length);
// // Set up the edges
// g.setEdge("10007154_1100", "148570017_1100", { label: "" });
// g.setEdge("148570017_1100", "148570018_1100", { label: "" });
// g.setEdge("148570018_1100", "148570019_1100", { label: "" });
// g.setEdge("148570018_1100", "148570025_1100", { label: "" });



// g.setEdge("148570019_1100", "148570020_1100", { label: "" });
// //put this line below line :25 to have a perfect graph
// g.setEdge("148570019_1100", "148570010_1100", { label: "" });
// g.setEdge("148570019_1100", "148570021_1100", { label: "" });



// g.setEdge("148570025_1100", "148570010_1100", { label: "" });
// g.setEdge("148570025_1100", "148570026_1100", { label: "" });
// g.setEdge("148570021_1100", "148570022_1100", { label: "" });
// g.setEdge("148570010_1100", "148570011_1100", { label: "" });
// g.setEdge("148570010_1100", "148570010_1200", { label: "" });
// g.setEdge("148570020_1100", "148570020_1200", { label: "" });
// g.setEdge("148570026_1100", "148570026_1200", { label: "" });
// g.setEdge("148570026_1200", "148570011_1200", { label: "" });
// g.setEdge("148570010_1200", "148570011_1200", { label: "" });
// g.setEdge("148570022_1100", "148570023_1100", { label: "" });
// g.setEdge("148570023_1100", "148570023_1200", { label: "" });

var svg = d3.select("svg"),
    inner = svg.select("g");

// Set the rankdir
g.graph().rankdir = "LR";
g.graph().nodesep = 60;

// Set up zoom support
function handleZoom(e) {
    d3.select('g.output')
        .attr('transform', e.transform);
}
let zoom = d3.zoom().on('zoom', handleZoom);

d3.select('svg').call(zoom);

// Create the renderer
var render = new dagreD3.render();


// Run the renderer. This is what draws the final graph.
render(inner, g);

