//controls the margins of a parent g element(the g element that holds all the other g elements)
const diagramMargin = { top: 0, bottom: 0, right: 0, left: 100 }
const width = 1000 - diagramMargin.right - diagramMargin.left;
const height = 1000 - diagramMargin.top - diagramMargin.bottom;
const margin = { top: 40, right: 120, bottom: 40, left: 320 };
const duration = 500;

const treeMap = d3.layout.tree().size([height, width]);
/*used to generate a smooth cubic(The ends of the line are square-like) from a source to a target
this is basiclly asking to take in the x and y from the source and the target in order 
to generate the appriate line between 2 nodes*/
const diagonalLinkGenerator = d3.svg.diagonal().projection(function (d) { return [d.y, d.x]; });
const svgWidth = width + margin.right + margin.left;
const svgHeight = height + margin.top + margin.bottom;
/*Note: The svg is not the area of the diagram instead its the alotted space where the diagram can "fit".
    if you diagram goes beyond these bounds it will not render think of it as a 'canvas' element
    */
//appends the svg element to the body element
const svg = d3.select("body").append("svg")
    .attr("width", svgWidth).attr("height", svgHeight)//the svg will dynamiclly resize as the user collapses and expands nodes
    .append("g")
    //translating the parent 'g' element so the entire diagram fits within the svg element
    .attr("transform", `translate(${margin.left},${margin.top})`);

//Creating the datatree that we will use to create the careerTreeData diagram
const careerTreeData = [
    {
        "parent": "null",
        "name": "Game Developer Intern",
        "children": [
            {
                "parent": "Game Developer Intern",
                "name": "Junior Game Developer",
                "children":
                    [
                        {
                            "parent": "Junior Game Developer",
                            "name": "Senior Game Developer",
                            "children":
                                [
                                    {
                                        "parent": "Senior Game Developer",
                                        "name": "Team Leader",
                                    }
                                ]
                        }
                    ]
            },

            {
                "parent": "Game Developer Intern",
                "name": "Junior Game Designer",
                "children":
                    [
                        {
                            "parent": "Junior Game Designer",
                            "name": "Senior Game Designer",
                        }
                    ]
            },

            {
                "parent": "Game Developer Intern",
                "name": "Junior Audio Engineer",
                "children":
                    [
                        {
                            "parent": "Junior Audio Engineer",
                            "name": "Senior Audio Engineer",
                        }
                    ]
            }


        ]
    }

];




/*The root's properties x0 is the location of the left edge of the rectangle  https://github.com/d3/d3-hierarchy
The root's property y0 is the location of each of the nodes. each node comes with this property and cna be used to minipulate position
*/
const root = careerTreeData[0];
root.x0 = width / 2;
root.y0 = 0;
let i = 0;
update(root);

d3.select(self.frameElement).style("height", "500px");
function update(rootParam) {
    // Compute the new careerTreeData layout.
    var nodes = treeMap.nodes(root).reverse(),
        links = treeMap.links(nodes);
    console.log(nodes);
    // Normalize for fixed-depth.
    nodes.forEach(function (d) { d.y = d.depth * 100; });

    // Update the nodes…
    //sets the id for the nodes this will be used to update links
    var node = svg.selectAll("g.node").data(nodes, function (d) {
        if (d.id != null) {
            return d.id;
        }
        else {
            d.id = i++;
            return d.id;
        }

    });

    // Enter any new nodes at the parent's previous position.
    var nodeEnter = node.enter().append("g")
        .attr("class", function (d) {

            if (d.children == null && d._children == null) {
                return "node";
            }
            return "node";
        })
        .attr("transform", function (d) { console.log(d.children); return "translate(" + rootParam.x0 + "," + rootParam.y0 + ")"; })
        .on("click", function (d) {
            if (d.children == null && d._children == null) {
                console.log("No children");
            }
            else {
                click(d);
            }

        });


    //console.log(node.enter());

    nodeEnter.append("circle")
        .attr("r", 10)
        .style("fill", function (d) { return d._children ? "red" : "#fff"; });

    nodeEnter.append("text")
        .attr("x", function (d) {
            if (d.children == null && d._children == null) {
                return 13;
            }
            else {
                return -13;
            }
        })
        .attr("dy", ".35em")
        .attr("text-anchor", function (d) {
            if (d.children == null && d._children == null) {
                return "start";
            }
            else {
                return "end";
            }
        })
        .text(function (d) { return d.name; })
        .style("fill-opacity", 10);// starting opacity is low then gets stronger through the animation

    // Transition nodes to their new position.
    var nodeUpdate = node.transition()
        .duration(duration)// how long it takes for the animation to complete
        .attr("transform", function (d) { console.log(`X:${d.x} Y:${d.y}`); return "translate(" + d.x + "," + d.y + ")"; });

    nodeUpdate.select("circle")
        .attr("r", 10)//r = radius
        .style("fill", function (d) { return d._children ? "red" : "#fff"; });

    nodeUpdate.select("text")
        .style("fill-opacity", 1);

    // Transition exiting nodes to the parent's new position.
    var nodeExit = node.exit().transition()
        .duration(duration)
        .attr("transform", function (d) { return "translate(" + source.x + "," + source.y + ")"; })
        .remove();

    nodeExit.select("circle")
        .attr("r", 1e-6);

    nodeExit.select("text")
        .style("fill-opacity", 1e-6);

    // Update the links…
    var link = svg.selectAll("path.link")
        .data(links, function (d) { return d.target.id; });

    // Enter any new links at the parent's previous position.
    link.enter().insert("path", "g")
        .attr("class", "link")
        .attr("d", function (d) {
            var o = { x: rootParam.x0, y: rootParam.y0 };
            return diagonalLinkGenerator({ rootParam: o, rootParam: o });
        });

    // Transition links to their new position.
    link.transition()
        .duration(duration)
        .attr("d", diagonalLinkGenerator);

    // Transition exiting nodes to the parent's new position.
    link.exit().transition()
        .duration(duration)
        .attr("d", function (d) {
            var o = { x: source.x, y: source.y };
            return diagonal({ source: o, target: o });
        })
        .remove();

    //Stash the old positions for transition.
    nodes.forEach(function (d) {
        d.x0 = d.x;
        d.y0 = d.y;
    });
}

// Toggle children on click.
function click(d) {
    if (d.children) {
        d._children = d.children;
        d.children = null;
    } else {
        d.children = d._children;
        d._children = null;
    }
    update(d);
}
